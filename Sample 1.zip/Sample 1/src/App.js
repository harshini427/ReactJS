import "./App.css";
import { BrowserRouter, Route, Routes} from "react-router-dom";
import EmployeeDetails from "./components/EmployeeDetails";
import Edit from "./components/Edit";
import EmployeeForm from "./components/EmployeeForm";
import LoginForm from "./components/LoginForm";

function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LoginForm />} />
          <Route path="/EmployeeDetails" element={<EmployeeDetails />} />
          <Route path="/edit/:id" element={<Edit />} />
          <Route path="/EmployeeForm" element={<EmployeeForm/>} /> 
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
