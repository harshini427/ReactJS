import React, { useState } from "react";
import { unameValidator, passwordValidator } from '../components/regexValidator';
import {useNavigate} from "react-router-dom";
import "./LoginForm.css";


const LoginForm = () => {
    const navigate = useNavigate()
    const [data,setData] = useState({
        username : '',
        password : ''
    })

    const [errorMessage, seterrorMessage] = React.useState('');
	const [successMessage, setsuccessMessage] = React.useState('');

    const {username,password} = data;

    const handleChange = e => {
        e.preventDefault();
		setData({ ...data, [e.target.name]: e.target.value });
	};


    const formSubmitter = e => {
		e.preventDefault();
		setsuccessMessage('');
		if (!unameValidator(data.username)) return seterrorMessage('Please enter valid user id');

		if (!passwordValidator(data.password))
			return seterrorMessage(
				'Password should have minimum 8 character with the combination of uppercase, lowercase, numbers and specialcharaters'
			);
		//setsuccessMessage('Successfully Validated');
		if(data.username !== 'Harshi$27' || data.password !== 'Qwert@12345') return seterrorMessage('Invalid username or password');
            
		navigate('/EmployeeDetails')

	};


return (
    <div className="container">
        <div className='btn-group btn-group-lg d-flex' role="group" aria-label="...">
          <button type="button" onClick={() => navigate('/')}>Login</button>
          <button type="button" onClick={() => navigate('/EmployeeDetails')}>Employees</button>
          <button type="button" className="active">Edit</button>
          <button type="button" onClick={() => navigate('/EmployeeForm')}>Add</button>
        </div>
        <div className="Container">
            <form className="login" onSubmit={formSubmitter}>
                <h1>Login</h1>
                {errorMessage.length > 0 && <div style={{ marginBottom: '10px', color: 'red' }}>{errorMessage}</div>}
                {successMessage.length > 0 && <div style={{ marginBottom: '10px', color: 'green' }}>{successMessage}</div>}
                <label htmlFor="username">Username</label>
                <input type="text" name="username" placeholder="username" id="username" value={username} onChange={handleChange} />
                <label htmlFor="password">Password</label>
                <input type="password" name="password" placeholder="password" id="password" value={password} onChange={handleChange}/>
                <button className="text-decoration-none btn btn-sm btn-dark" type="submit">Submit</button>
            </form>
        </div>
    </div>
)
}

export default LoginForm;