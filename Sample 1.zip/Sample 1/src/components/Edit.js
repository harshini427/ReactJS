import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';

function Edit() {

    const {id} = useParams();
    const [values, setValues] = useState({
        id: id,
        name: '',
        sex: '',
        dob: '',
        salary: '',
        department: ''
    })

    useEffect(() => {
        axios.get('http://localhost:3000/users/'+id)
        .then(res => {
            setValues({...values, name: res.data.name, sex: res.data.sex, dob: res.data.dob, salary: res.data.salary, department: res.data.department})
        })
        .catch(err => console.log(err))
    }, [])
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.put(`http://localhost:3000/users/`+id, values)
        .then(res => {
            navigate('/EmployeeDetails');
        })
        .catch(err => console.log(err))
    }

    return (
    <div className='d-flex w-100 vh-100 justify-content-center align-items-center'>
        <div className='w-50 border bg-secoundary text-black p-5'>
        <form onSubmit={handleSubmit}>
            <h1 >Edit Employees Data</h1>
            <div>
                <label htmlFor="name">Name</label>
                <input type="text" name='name' className='form-control' placeholder='Enter Name' 
                value={values.name} onChange={e => setValues({...values, name: e.target.value})}/>
            </div>
            <div>
                <label htmlFor="sex">Sex</label>
                <input type="text" name='sex' className='form-control' placeholder='Enter M or F' 
                value={values.sex} onChange={e => setValues({...values, sex: e.target.value})}/>
            </div>
            <div>
                <label htmlFor="dob">DOB</label>
                <input type="date" name='dob' className='form-control' placeholder='Enter dob' 
                value={values.dob} onChange={e => setValues({...values, dob: e.target.value})}/>
            </div>
            <div>
                <label htmlFor="salary">Salary</label>
                <input type="number" name='salary' className='form-control' 
                value={values.salary} onChange={e => setValues({...values, salary: e.target.value})}/>
            </div>
            <div>
                <label htmlFor="department">Department</label>
                <input type="text" name='department' className='form-control' 
                value={values.department} onChange={e => setValues({...values, department: e.target.value})}/>
            </div><br />
            <button className='btn btn-info'>Update</button>
        </form>
        </div>
    </div>
    )
}

export default Edit;
