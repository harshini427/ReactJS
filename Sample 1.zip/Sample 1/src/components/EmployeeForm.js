import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, } from 'react-router-dom';
import './EmployeeForm.css'; // Import the CSS file for EmployeeForm styling

function EmployeeForm() {
  const [inputData, setInputData] = useState({name:'', sex:'', dob:'', salary:'', department:''})
  const navigate = useNavigate();


  function handleSubmit(e) {
    e.preventDefault()
    axios.post('http://localhost:3000/users',inputData) 
    .then(res => {
      navigate('/EmployeeDetails');
      window.location.reload();
    })
    .catch(err => console.log(err));
  }
  return (
    
    <div className='employee-form'>
      <div className='form-container'></div>
      <form onSubmit={handleSubmit} >
        {/* Form content */}
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input type="text" id="name" name="name" className='form-control'
          onChange={e => setInputData({...inputData, name: e.target.value})} required/>
        </div>

        <div className="form-group">
          <label htmlFor="sex">Sex:</label>
          <select id="sex" name="sex" className='form-control' required
            onChange={e => setInputData({...inputData, sex: e.target.value})}>
            <option value="">Select</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="dob">Date of Birth:</label>
          <input type="date" id="dob" name="dob" className='form-control'
          onChange={e => setInputData({...inputData, dob: e.target.value})} required/>
        </div>

        <div className="form-group">
          <label htmlFor="salary">Salary:</label>
          <input type="number" id="salary"
            name="salary"
            onChange={e => setInputData({...inputData, salary: e.target.value})}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="department">Department:</label>
          <input
            type="text"
            id="department"
            name="department"
            onChange={e => setInputData({...inputData, department: e.target.value})}
            required
          />
        </div>

        <div className="form-group button-group">
          <button type="submit">Submit</button>
        </div>
      </form>
    </div>
  );
}

export default EmployeeForm;

