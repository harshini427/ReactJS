import React, { useState, useEffect } from "react";
import axios from "axios";
import "./EmployeeDetails.css";
import { Link, useNavigate } from "react-router-dom";

function EmployeeDetails() {
  const [data, setData] = useState([]);
  const [showConfirmation, setShowConfirmation] = useState(false); // State to control the confirmation popup
  const [selectedUserId, setSelectedUserId] = useState(null); // State to store the ID of the selected user to be deleted
  const navigate = useNavigate();

  const handleDelete = (id) => {
    setSelectedUserId(id);
    setShowConfirmation(true);
  };

  const confirmDelete = () => {
    axios
      .delete(`http://localhost:3000/users/${selectedUserId}`)
      .then((res) => {
        window.location.reload();
      })
      .catch((err) => console.log(err));
  };

  const cancelDelete = () => {
    setSelectedUserId(null);
    setShowConfirmation(false);
  };

  useEffect(() => {
    axios
      .get(`http://localhost:3000/users`)
      .then((res) => setData(res.data))
      .catch((err) => console.log(err));
  }, []);

  return (
    <div className="container">
      <div className="btn-group btn-group-lg d-flex" role="group" aria-label="....">
        <button type="button" onClick={() => navigate("/")}>Login</button>
        <button type="button" onClick={() => navigate("/EmployeeDetails")}>Employees</button>
        <button type="button" className="active">Edit</button>
        <button type="button" onClick={() => navigate("/EmployeeForm")}>Add</button>
      </div>
      <div className="form-div">
        <table className="table table-striped table-bordered table-responsive">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Sex</th>
              <th>DOB</th>
              <th>Salary</th>
              <th>Department</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.map((user, index) => (
              <tr key={index}>
                <td>{user.id}</td>
                <td>{user.name}</td>
                <td>{user.sex}</td>
                <td>{user.dob}</td>
                <td>{user.salary}</td>
                <td>{user.department}</td>
                <td>
                  <Link className="text-decoration-none btn btn-sm btn-success" to={`/edit/${user.id}`}>Edit</Link>
                  <button onClick={() => handleDelete(user.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {/* Confirmation Popup */}
      {showConfirmation && (
        <div className="confirmation-popup">
          <div className="confirmation-content">
            <h3>Confirm Delete</h3>
            <p>Are you sure you want to delete this user?</p>
            <div className="confirmation-buttons">
              <button className="btn btn-danger" onClick={confirmDelete}>Delete</button>
              <button className="btn btn-secondary" onClick={cancelDelete}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default EmployeeDetails;
